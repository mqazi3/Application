import java.util.Scanner;
import java.util.PriorityQueue;
import java.util.Comparator;
import java.util.LinkedList;
import java.io.*;
import java.io.IOException;
import java.io.FileReader;
import java.io.PrintWriter;

class HuffmanNode
{
    int val;
    char decrypted;
    HuffmanNode left;
    HuffmanNode right;
}

class dataReference implements Comparator<HuffmanNode>
{
    public int compare(HuffmanNode first, HuffmanNode second)
    {
        return first.val - second.val;
    }
}

public class ProjectThreeData
{
    public static void main( String [] args ) throws IOException
    {
        System.out.println( "Hello. To commence the process of translating the encrypted or the decrypted string, enter in the file-path of the frequency table." ) ;
        System.out.println( "When entering in the file-path of the location possessing the text-file of the frequency table, enter in another slash followed with the name of the file." ) ;
        System.out.println( "If necessary, remove the text-file from a zip-folder to prevent any error occurrences." ) ;
        Scanner input = new Scanner(System.in);
        String filepath1 = input.nextLine();
        // prompt for the user to submit the file-path of the frequency-table file.

        System.out.println( "Now, select the file-path for the output-file that displays the character-code relationship data, utilized in encryption and decryption." ) ;
        System.out.println( "Ensure that the secondary file-path exists as outside of a zip-folder when necesssary to prevent any errors." ) ;
        System.out.println( "The user may opt for any custom name of the output-file. The system later reads this file to reference codes for characters." ) ;
        // prompt for the user to submit the file-path of the character-code file referenced later.
        FileReader fileOne = new FileReader(filepath1);
        String filepath2 = input.nextLine();
        PrintWriter fileTwo = new PrintWriter(filepath2);
        Scanner fileReader = new Scanner(fileOne);

        LinkedList<String> data1 = new LinkedList<String>(); // this list stores the letters of the frequency table.
        LinkedList<String> data2 = new LinkedList<String>(); // this list stores the frequencies of the letters within the frequency table.
        int tracker = 0;

        while (fileReader.hasNext())
        {
            String reference = fileReader.nextLine(); // scan for the current row of the file possessing the frequency-data.
            int length = reference.length(); // obtain the length of the rows within the frequency-data file.
            String initialOne = "";
            String initialTwo = ""; // set the string possessing the number of the frequency corresponding to the current character.
            int index = 0;
            char conversion = reference.charAt(0);
            String conversion2 = String.valueOf(conversion); // scan for the first-index entity of the scanned string of the frequency-data file.
            data1.add(conversion2); // add the letter into the data1 string possessing letters.
            for (int x = 0; x < length; x = x + 1)
            {
                // for every index of the scanned string, scan for any numbers.
                char check = reference.charAt(x);
                String check2 = String.valueOf(check);
                if (check2.equals("0") || check2.equals("1") || check2.equals("2") || check2.equals("3") || check2.equals("4") || check2.equals("5") || check2.equals("6") || check2.equals("7") || check2.equals("8") || check2.equals("9"))
                {
                    initialTwo = initialTwo + check2;
                    // store any numbers into the temporary string corresponding to the frequency-value.
                }
            }
            data2.add(initialTwo); // store the string of the frequency-value of the currently-scanned character into the data2 list.
            tracker = tracker + 1; // increase the value of this object to determine the final number of items within the data1 and data2 lists.
        }
        System.out.println( data1 ) ; // print out the list of data1.
        System.out.println( data2 ) ; // print out the list of data2.

        PriorityQueue<HuffmanNode> treeData = new PriorityQueue<HuffmanNode>(tracker, new dataReference()); // set the object of a priority-queue.
        for (int x2 = 0; x2 < tracker; x2 = x2 + 1)
        {
            HuffmanNode treeData2 = new HuffmanNode(); // set a new temporary node.
            String fix11 = data1.get(x2);
            char fix1 = fix11.charAt(0);
            treeData2.decrypted = fix1; // set the current letter of the data1 list as the data-representation of the temporary node.
            String fix22 = data2.get(x2);
            int fix2 = Integer.valueOf(fix22); // set the current value corresponding to the frequency of the current-character as the value of the node.
            treeData2.val = fix2;
            treeData2.left = null; // set the left-pointer of the node as null.
            treeData2.right = null; // set the right-pointer of the node as null.
            treeData.add(treeData2); // add the node into the queue, storing it into a node-form within the tree.
        }
        HuffmanNode rootNode = null; // set a pointer for a root-node within the tree.

        while (treeData.size() > 1) // initiate a loop for the duration of the size of the tree-data.
        {
            HuffmanNode first = treeData.peek(); // scan for the lowest value within the tree, setting it into a temporary node.
            treeData.poll();
            HuffmanNode second = treeData.peek(); // scan for the second-lowest value within the tree, setting it into a temporary node.
            treeData.poll();
            HuffmanNode root2 = new HuffmanNode(); // develop a new temporary node.
            root2.val = first.val + second.val; // set the value of the node as the combined value of the referenced nodes.
            root2.decrypted = '-'; // set the data-representation of the string as neutral relative to characters.
            root2.left = first; // set the left-child of the combined node as the smallest of the two reference-nodes.
            root2.right = second; // set the right-child of the combined node as the second-smallest of the two reference nodes.
            rootNode = root2; // set the combined node as the current root-pointer.
            treeData.add(root2); // add the combined node into the queue.
        }
        System.out.println( "The data shall now display both the characters and their corresponding codes." ) ;
        String [][] conversionReference = new String[2][tracker]; // set the multi-dimensional array possessing the character-code relationship.
        String codeData = ""; // set the code-string as a blank slate, referenced later.
        displayData(fileTwo, rootNode, codeData); // call the recursive method to print out characters and their codes.
        fileTwo.close();
        FileReader fileOne2;
        fileOne2 = new FileReader(filepath2); // store the file possessing the code-character data into a file-reader referenced later.
        Scanner fileReader2 = new Scanner(fileOne2);
        for (int a = 0; a < data1.size(); a = a + 1)
        {
            conversionReference[0][a] = data1.get(a);
        }

        {
            while (fileReader2.hasNext())
            {
                String referenceCode = fileReader2.nextLine(); // for any row within the newly created output-file, scan the row to store it into a string.
                String codeValue = ""; // set a temporary string into a blank state.
                for (int a2 = 0; a2 < referenceCode.length(); a2 = a2 + 1)
                {
                    char checkReference = referenceCode.charAt(a2);
                    String checkReference2 = String.valueOf(checkReference);
                    if (checkReference2.equals("0") || checkReference2.equals("1") || checkReference2.equals("2") || checkReference2.equals("3") || checkReference2.equals("4") || checkReference2.equals("5") || checkReference2.equals("6") || checkReference2.equals("7") || checkReference2.equals("8") || checkReference2.equals("9"))
                    {
                        codeValue = codeValue + checkReference2;
                        // for any numerical value present within the row-string, add the value into the temporary string.
                    }
                }
                char characterReference = referenceCode.charAt(0);
                String codeValue2 = String.valueOf(characterReference); // reference the letter that starts the row-string within the output-data.
                for (int a3 = 0; a3 < data1.size(); a3 = a3 + 1)
                {
                    String matchArray = conversionReference[0][a3];
                    if (codeValue2.equals(matchArray))
                    {
                        conversionReference[1][a3] = codeValue;
                        // for any letter within the conversionReference array that matches the currently-scanned letter, add the code-data into the second array-row.
                    }
                }
            }
            System.out.println( "" ) ;
            System.out.println( "If the user wishes to translate a non-decrypted string of code-data in an input-file, enter 1 to continue." ) ;
            System.out.println( "If the user wishes to instead translate a decrypted string in an input-file, enter 2 to continue." ) ;
            // prompt for the user to translate a non-decrypted file or a decrypted file.
            // an invalid entry results in the program asking the user for another input or offering an end-choice-option to the user.
            boolean runLoop = true; // set a boolean to run the loop of the program for conversion.
            int choice = 0;
            choice = input.nextInt(); // allow for the user-choice.
            do
            {
                if (choice == 1) // if the user opts to decrypt a file, ask them to input the file-path of the reference file.
                {
                    System.out.println( "Enter in the file-path associated with the non-decrypted string followed with the name of the text-file at the end of the file-path." ) ;
                    System.out.println( "If necessary, ensure that the text-file exists as placed outside of a zip-folder to prevent any error conditions." ) ;
                    // prompt for the user to submit the file for conversion.
                    String filePath3 = null;
                    filePath3 = input.nextLine();
                    filePath3 = input.nextLine();
                    FileReader fileOne3;
                    fileOne3 = new FileReader(filePath3);
                    Scanner fileReader3 = new Scanner(fileOne3);
                    while (fileReader3.hasNext())
                    {
                        String translation1 = fileReader3.nextLine(); // scan for the current row of the non-decrypted-data file.
                        int translationLength1 = translation1.length(); // set a length relating to the scanned string.
                        String comparisonCheck = ""; // set a temporary string that tracks the code to convert and translate.
                        for (int a4 = 0; a4 < translationLength1; a4 = a4 + 1)
                        {
                            char indexReference = translation1.charAt(a4);
                            String indexReference2 = String.valueOf(indexReference);
                            comparisonCheck = comparisonCheck + indexReference2; // scan the reference-string at the current index, adding the value to the temporary string.
                            for (int a5 = 0; a5 < data1.size(); a5 = a5 + 1)
                            {
                                String arrayCheck = conversionReference[1][a5];
                                if (arrayCheck.equals(comparisonCheck))
                                {
                                    System.out.print( conversionReference[0][a5] ) ;
                                    comparisonCheck = "";
                                    // in the event of the temporary string matching any code within the conversionReference array, print the corresponding character associated with that code.
                                    // reset the temporary string to a neutral-state to repeat the process for the next code within the string.
                                }
                            }
                        }
                        System.out.println( "" ) ;
                        // repeat the process for the next row within the data.
                    }
                }
                if (choice == 2) // in the event of the user opting for decrypted-translation, prompt for the file-path entry.
                {
                    System.out.println( "Enter in the file-path associated with the decrypted string followed with the name of the text-file at the end of the file-path." ) ;
                    System.out.println( "If necessary, ensure that the text-file exists as placed outside of a zip-folder to prevent any error conditions." ) ;
                    // prompt for the user to submit the file-path of the decrypted data.
                    String filePath4 = null;
                    filePath4 = input.nextLine();
                    filePath4 = input.nextLine();
                    FileReader fileOne4;
                    fileOne4 = new FileReader(filePath4);
                    Scanner fileReader4 = new Scanner(fileOne4);
                    while (fileReader4.hasNext())
                    {
                        String translation2 = fileReader4.nextLine(); // scan for the current row within the decrypted-data file.
                        String [] conversionCharacter = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
                        String [] conversionCharacter2 = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
                        // set the arrays corresponding to the letters.
                        String translationFinal = ""; // set a temporary string corresponding to the newer version of the string.
                        for (int a6 = 0; a6 < translation2.length(); a6 = a6 + 1)
                        {
                            char indexConfirmation = translation2.charAt(a6);
                            String indexConfirmation2 = String.valueOf(indexConfirmation); // scan for the current-index entity of the decrypted string.
                            int errorConditionFix = 0; // set an errorCondition tracker, referenced later.
                            if (indexConfirmation2.equals(" "))
                            {
                                translationFinal = translationFinal + indexConfirmation2; // for any empty space within the scanned string, add it into the final-string data.
                                errorConditionFix = 1; // set the errorCondition tracker to 1.
                            }
                            else
                            {
                                for (int a7 = 0; a7 < data1.size(); a7 = a7 + 1) // otherwise, trigger a loop to scan for any letter within the decrypted-string.
                                {
                                    String confirmationOne = conversionCharacter[a7]; // set temporary trackers for the letters of the arrays.
                                    String confirmationTwo = conversionCharacter2[a7];
                                    if (indexConfirmation2.equals(confirmationOne)) // if the currently-scanned index of the decrypted string matches a letter, add the capitalized version of the letter into the final-string data.
                                    {
                                        translationFinal = translationFinal + confirmationOne;
                                        errorConditionFix = 1;
                                        // set errorCondition to 1.
                                    }
                                    if (indexConfirmation2.equals(confirmationTwo))
                                    {
                                        translationFinal = translationFinal + confirmationOne;
                                        errorConditionFix = 1;
                                    }
                                }
                            }
                            if (errorConditionFix == 0) // if the loop never added in the currently-scanned index-entity into the final string, add it in.
                            {
                                translationFinal = translationFinal + indexConfirmation2;
                            }
                        }
                        System.out.println( "The updated version of the current decrypted string shall display below." ) ;
                        System.out.println( translationFinal ) ; // print out the updated version of the decrypted string.
                        String finalData = ""; // set the final-encryption string in a neutral state.
                        for (int a8 = 0; a8 < translationFinal.length(); a8 = a8 + 1) // start the process of encrypting the string.
                        {
                            char dataTranslation = translationFinal.charAt(a8);
                            String dataTranslation2 = String.valueOf(dataTranslation);
                            int errorFix2 = 0; // set the errorFix2 tracker.
                            for (int a9 = 0; a9 < data1.size(); a9 = a9 + 1)
                            {
                                String comparisonMatch = conversionReference[0][a9];
                                if (comparisonMatch.equals(dataTranslation2))
                                {
                                    finalData = finalData + conversionReference[1][a9];
                                    errorFix2 = 1;
                                    // add any code corresponding to the currently-scanned letter of the string into the final-encryption string.
                                    // set the errorFix2 tracker to 1.
                                }
                            }
                            if (dataTranslation2.equals(" "))
                            {
                                finalData = finalData + " ";
                                errorFix2 = 1;
                                // add any empty space into the encrypted string for context.
                                // set the errorFix2 tracker to 1.
                            }
                            if (errorFix2 == 0)
                            {
                                finalData = finalData + dataTranslation2;
                                // for any entity within the decrypted-string not added into the final encrypted string, add it in.
                            }
                        }
                        System.out.println( finalData ) ; // print out the final encrypted string.
                        System.out.println( "" ) ;
                    }
                }
                System.out.println( "The program shall now continue to allow another chance at encryption and decryption. To end the program, enter in 3. To continue, enter in any other input." ) ;
                choice = input.nextInt();
                // allow for the user to end the program.
                if (choice == 3)
                {
                    runLoop = false;
                }
                else
                {
                    // allow for the user to continue the conversions with other files.
                    System.out.println( "The user opted to continue." ) ;
                    System.out.println( "If the user wishes to translate a non-decrypted string of letters in an input-file, enter 1 to continue." ) ;
                    System.out.println( "If the user wishes to instead translate a decrypted string in an input-file, enter 2 to continue." ) ;
                    choice = input.nextInt();
                }
            } while (runLoop);
        }
        fileOne.close();
    }
    public static void displayData(PrintWriter fileTwo, HuffmanNode rootNode, String codeData)
    {
        // in the event of a leaf node that can only ever refer to a character, print it out and its code, storing it into the output-file.
        if (rootNode.left == null && rootNode.right == null && Character.isLetter(rootNode.decrypted))
        {
            System.out.println( rootNode.decrypted + " " + codeData ) ;
            fileTwo.println( rootNode.decrypted + " " + codeData ) ;
        }
        // for any left-path options, recursively call the method.
        if (rootNode.left != null)
        {
            displayData(fileTwo, rootNode.left, codeData + "0"); // add 0 to the codeData string.
        }
        // for any right-path options, recursively call the method.
        if (rootNode.right != null)
        {
            displayData(fileTwo, rootNode.right, codeData + "1"); // add 1 to the codeData string.
        }
    }
}