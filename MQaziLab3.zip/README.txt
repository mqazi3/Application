// Run the ProjectThreeData file.
// Upon running it, enter in the file-path associated with the referenced frequency table.
// Enter in the file-path that stores data for the characters in the frequency table and their codes.
// Select the corresponding option to translate an encrypted string into a decrypted one, or an opposite effect.
// If desired, enter in the option to end the program.
// For any error-prevention, ensure that the frequency table scanned in the beginning possesses the required characters.